public class ShowPopUp implements User {

    @Override
    public void update() {
        System.out.println("Propaganda mostrada no pop-up");
    }

}
