public interface User {
    void update();
}
