public class ShowEmail implements User{

    @Override
    public void update() {
        System.out.println("Propaganda enviada para o email");
    }

}
