public class User {

	private String username;

	private int idUsuario;

	private Aluguel aluguel;

}
