public interface EstadoUser {
    void estado(User user, int estado);
}
