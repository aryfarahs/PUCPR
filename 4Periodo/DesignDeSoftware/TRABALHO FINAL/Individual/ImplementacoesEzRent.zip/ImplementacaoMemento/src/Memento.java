public class Memento {
    private final String nameItem;

    // CONSTRUTOR
    public Memento(String nameItem) {
        this.nameItem = nameItem;
    }

    public String getNameItem() {
        return nameItem;
    }




}
